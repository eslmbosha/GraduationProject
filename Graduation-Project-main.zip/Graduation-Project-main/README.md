# Digieator
Requirements:

• Conversions between number system in binary, decimal, octal and
hexadecimal.

• Provide logical operations (AND, OR, XOR, NAND, NOR, XNOR and NOT).

• guide to tell the user how to use the app.

• multicolor keyboard calculator.

• support for different screen sizes.

• detailed explanation of the answer for the user’s understanding.

• Provide different modes (dark, light).

• Support arithmetic operation (addition, subtraction, division and
multiplication)??.

• Fast responsive.

• viewing previous calculation.

• Support logic shift left, and logic shift right.

• Support brackets??.

• Characterized by Red bit in binary number which is the least significant bit
(lsb).

• Support copy, paste and share result.

• Adaptive text size



## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
