part of 'theme_cubit.dart';

abstract class ThemeState {}

class ThemeStateLight extends ThemeState {}

class ThemeStateDark extends ThemeState {}

class ThemeStateSystem extends ThemeState {}
